package Flipkart;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductSelection {
	 public static void main(String[] args) {
		 
		    WebDriver driver =new ChromeDriver();
		    driver.manage().window().maximize();
		    
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	        driver.get("https://www.flipkart.com/");
	        //driver.findElement(By.xpath("//span[text()='✕']")).click();
	        driver.findElement(By.name("q")).sendKeys("iphone");
	        driver.findElement(By.xpath("//button[@type='submit']")).click();

	        
	        WebElement appleFilter = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("//div[text()='Apple']")));
	        appleFilter.click();

	        // Step 5: Select first product from results
	        WebElement firstProduct = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("(//div[contains(@class,'_4rR01T')])[1]")));

	        String productNameFromList = firstProduct.getText();
	        System.out.println("Selected Product: " + productNameFromList);

	        firstProduct.click();

	        // Step 6: Switch to product details tab
	        Set<String> windows = driver.getWindowHandles();
	        for (String window : windows) {
	            driver.switchTo().window(window);
	        }

	        // Step 7: Capture product name and price
	        WebElement productName = wait.until(
	                ExpectedConditions.visibilityOfElementLocated(
	                        By.xpath("//span[contains(@class,'B_NuCI')]")));

	        WebElement productPrice = wait.until(
	                ExpectedConditions.visibilityOfElementLocated(
	                        By.xpath("//div[contains(@class,'_30jeq3')]")));

	        // Step 8: Print product details
	        System.out.println("Product Name : " + productName.getText());
	        System.out.println("Product Price: " + productPrice.getText());

	        // driver.quit();
	    }
	
}
		
	



